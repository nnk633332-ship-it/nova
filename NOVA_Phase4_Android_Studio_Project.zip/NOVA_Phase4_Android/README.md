# NOVA — Android Phase 4 starter

This is a native Android Studio Kotlin project starter for Phase 4 phone-control integration.

## Included
- Native Android app entry point (`MainActivity`)
- Open Wi-Fi and Bluetooth system panels
- Open Android Settings
- Read battery percentage
- Ask Android for explicit screen-capture consent using MediaProjection

## Important safety and platform limits
- Wi-Fi/Bluetooth actions open Android's system UI. NOVA does not silently toggle device radios.
- Screen capture requires the Android consent prompt. This starter requests permission but does not yet record or save screenshots.
- No hidden access, permission bypass, remote surveillance, or unrestricted device control is included.
- The original NOVA split-screen dashboard assets were not present in the available project files, so this starter intentionally does not replace that design with a new one.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync (internet may be required for the first sync).
3. Select a connected Android device or emulator.
4. Run the `app` configuration.

To create an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

Package name: `com.nova.assistant`
Minimum Android version: Android 8.0 (API 26)
Target SDK: 35
