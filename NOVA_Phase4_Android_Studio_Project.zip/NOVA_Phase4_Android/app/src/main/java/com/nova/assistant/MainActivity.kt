package com.nova.assistant

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {

    private val screenCaptureRequest = 4104

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }

        val title = TextView(this).apply {
            text = "NOVA — Phase 4"
            textSize = 26f
        }
        val note = TextView(this).apply {
            text = "Phone controls work through Android's official system screens and permissions."
            textSize = 15f
            setPadding(0, 12, 0, 24)
        }

        layout.addView(title)
        layout.addView(note)
        layout.addView(actionButton("Open Wi-Fi settings") {
            openSystemPage(Settings.Panel.ACTION_WIFI)
        })
        layout.addView(actionButton("Open Bluetooth settings") {
            openSystemPage(Settings.Panel.ACTION_BLUETOOTH)
        })
        layout.addView(actionButton("Open device settings") {
            safeStart(Intent(Settings.ACTION_SETTINGS))
        })
        layout.addView(actionButton("Show battery status") {
            showBatteryStatus()
        })
        layout.addView(actionButton("Request screen-capture permission") {
            requestScreenCapturePermission()
        })

        setContentView(layout)
    }

    private fun actionButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            setOnClickListener { action() }
        }

    private fun openSystemPage(action: String) {
        // Android displays its own panel; NOVA does not silently change radio settings.
        safeStart(Intent(action))
    }

    private fun safeStart(intent: Intent) {
        try {
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "This screen is not available on this device.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showBatteryStatus() {
        val batteryManager = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val text = if (level in 0..100) "Battery: $level%" else "Battery level unavailable"
        Toast.makeText(this, text, Toast.LENGTH_LONG).show()
    }

    private fun requestScreenCapturePermission() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        // Android shows a consent prompt. Capture cannot begin unless the user approves it.
        startActivityForResult(manager.createScreenCaptureIntent(), screenCaptureRequest)
    }

    @Deprecated("Android activity result callback retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == screenCaptureRequest) {
            val message = if (resultCode == Activity.RESULT_OK && data != null) {
                "Permission granted for this session. Screenshot capture service is the next integration step."
            } else {
                "Screen capture was not approved."
            }
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
    }
}
