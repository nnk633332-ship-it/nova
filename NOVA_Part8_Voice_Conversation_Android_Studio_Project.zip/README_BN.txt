NOVA Part 8 — Voice Conversation (Starter)

এই ZIP-এ Android Studio source project আছে, APK নয়।

এই ধাপে:
- বোতাম চেপে কথোপকথন শুরু করা যায়।
- Android SpeechRecognizer দিয়ে বাংলা কথাকে text-এ রূপান্তর করার চেষ্টা করে।
- TextToSpeech দিয়ে উত্তর পড়ে শোনায়।
- উত্তর দেওয়ার পরে আবার শুনতে শুরু করে; Stop বোতামে বন্ধ হয়।
- কয়েকটি সাধারণ local reply আছে।

সীমাবদ্ধতা:
- এটি এখনো পূর্ণ AI assistant নয়। সাধারণ প্রশ্নের বুদ্ধিমান উত্তর দেওয়ার জন্য নিরাপদ online AI backend/API সংযোগ পরের ধাপ।
- ফোনের Speech Recognition engine, internet, ভাষা প্যাক ও Android version অনুযায়ী বাংলা recognition/TTS বদলাতে পারে।
- এটি সবসময় background-এ শোনে না; ব্যবহারকারী Start চাপলে তবেই শোনে।
- আগের Part 4–7 source ZIP এখানে পাওয়া যায়নি, তাই এই ZIP একটি স্বতন্ত্র Part 8 starter; আগের screenshot/Wi-Fi/Bluetooth ইত্যাদি ফিচার এতে একত্রিত করা হয়নি।
- Android Studio-তে খুলে Gradle sync/build করে পরীক্ষা করতে হবে। এখানে build/device test করা হয়নি।
