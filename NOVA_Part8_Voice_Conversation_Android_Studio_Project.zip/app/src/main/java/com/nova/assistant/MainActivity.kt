package com.nova.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var heard: TextView
    private lateinit var reply: TextView
    private lateinit var listenButton: Button
    private lateinit var stopButton: Button
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var conversationOn = false
    private var readyToSpeak = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "এই ফোনে Speech Recognition পাওয়া যাচ্ছে না।"
            listenButton.isEnabled = false
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 71)
        }
    }

    private fun buildScreen() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 48, 28, 24)
            setBackgroundColor(0xFF071426.toInt())
        }
        fun label(text: String, size: Float): TextView = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER; setPadding(8, 16, 8, 16)
        }
        layout.addView(label("NOVA", 32f))
        status = label("কথা বলার জন্য প্রস্তুত", 17f); layout.addView(status)
        heard = label("তুমি যা বলবে, এখানে দেখা যাবে", 16f); layout.addView(heard)
        reply = label("NOVA-র উত্তর এখানে দেখা যাবে", 18f); layout.addView(reply)
        listenButton = Button(this).apply {
            text = "কথা বলা শুরু করো"
            setOnClickListener { startConversation() }
        }
        stopButton = Button(this).apply {
            text = "কথা বলা বন্ধ"
            setOnClickListener { stopConversation() }
        }
        layout.addView(listenButton); layout.addView(stopButton)
        layout.addView(label("মাইক্রোফোন অনুমতি প্রয়োজন। ফোনের Speech Recognition পরিষেবা অনুযায়ী ভাষা ও অফলাইন সুবিধা কাজ করবে।", 13f))
        setContentView(layout)
    }

    override fun onInit(result: Int) {
        readyToSpeak = result == TextToSpeech.SUCCESS
        if (readyToSpeak) {
            val set = tts?.setLanguage(Locale("bn", "IN")) ?: TextToSpeech.LANG_NOT_SUPPORTED
            if (set == TextToSpeech.LANG_MISSING_DATA || set == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale("en", "IN"))
            }
        }
    }

    private fun startConversation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 71)
            return
        }
        conversationOn = true
        listenButton.isEnabled = false
        status.text = "শুনছি…"
        listenOnce()
    }

    private fun listenOnce() {
        if (!conversationOn) return
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
                sr.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { status.text = "NOVA শুনছে…" }
                    override fun onBeginningOfSpeech() { status.text = "তোমার কথা শুনছি…" }
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { status.text = "কথা বুঝছি…" }
                    override fun onError(error: Int) {
                        status.text = "শোনা যায়নি। আবার চেষ্টা করছি…"
                        if (conversationOn) listenOnce()
                    }
                    override fun onResults(results: Bundle?) {
                        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                        heard.text = "তুমি বলেছ: $text"
                        val answer = makeLocalReply(text)
                        reply.text = "NOVA: $answer"
                        status.text = "উত্তর দিচ্ছি…"
                        if (readyToSpeak) {
                            tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "nova_reply")
                            tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                                override fun onStart(utteranceId: String?) {}
                                override fun onDone(utteranceId: String?) { runOnUiThread { if (conversationOn) listenOnce() } }
                                override fun onError(utteranceId: String?) { runOnUiThread { if (conversationOn) listenOnce() } }
                            })
                        } else if (conversationOn) {
                            listenOnce()
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try { recognizer?.startListening(intent) } catch (_: Exception) {
            status.text = "ভয়েস পরিষেবা চালু করা যায়নি।"
            stopConversation()
        }
    }

    private fun makeLocalReply(input: String): String {
        val q = input.lowercase(Locale.ROOT)
        return when {
            q.isBlank() -> "আমি ঠিকমতো শুনতে পাইনি। আরেকবার বলবে?"
            listOf("হ্যালো", "হাই", "hello", "নোভা").any { q.contains(it) } ->
                "হ্যাঁ, আমি শুনছি। কী জানতে চাও?"
            listOf("তোমার নাম", "তুমি কে", "who are you").any { q.contains(it) } ->
                "আমার নাম NOVA। আমি তোমার ফোনের সহকারী অ্যাপ।"
            listOf("সময়", "কটা বাজে", "time").any { q.contains(it) } ->
                "আমি এখনো ঘড়ির তথ্যের সঙ্গে যুক্ত হইনি।"
            listOf("বন্ধ", "থামো", "stop").any { q.contains(it) } -> {
                stopConversation()
                "ঠিক আছে, কথোপকথন বন্ধ করছি।"
            }
            else -> "তোমার কথা শুনেছি: $input। এখনো আমার পূর্ণ AI উত্তর ব্যবস্থা যুক্ত হয়নি।"
        }
    }

    private fun stopConversation() {
        conversationOn = false
        try { recognizer?.cancel() } catch (_: Exception) {}
        status.text = "কথোপকথন বন্ধ"
        listenButton.isEnabled = true
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 71 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            status.text = "মাইক্রোফোন অনুমতি পাওয়া গেছে।"
        } else if (requestCode == 71) {
            status.text = "মাইক্রোফোন অনুমতি ছাড়া কথা শোনা যাবে না।"
        }
    }

    override fun onDestroy() {
        conversationOn = false
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
