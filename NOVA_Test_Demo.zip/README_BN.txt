NOVA TEST DEMO

চালানোর নিয়ম:
1) ZIP Extract করে index.html Chrome-এ খোলো।
2) ভয়েস ইনপুটের জন্য Chrome-এ microphone permission দাও এবং internet লাগতে পারে।
3) Home screen-এ নিতে Chrome menu (⋮) > Add to Home screen নির্বাচন করো।

এটি APK নয়; ফোনে NOVA-র প্রাথমিক UI ও মৌলিক কাজ পরীক্ষা করার PWA prototype।
এতে offline cached interface, Normal/Shadow mode, basic canned replies, browser speech recognition ও text-to-speech আছে।
এতে full AI, background wake word, screenshot capture বা Android system-control নেই।
