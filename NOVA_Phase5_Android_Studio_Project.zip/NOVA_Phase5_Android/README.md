# NOVA — Phase 5 Android Studio project

Phase 5 adds a one-shot screenshot capture flow to the Phase 4 native Android starter.

## Included
- Tap **Take screen screenshot**
- Android shows its own screen-capture consent dialog
- If approved, NOVA captures one frame and saves a PNG under `Pictures/NOVA`
- Foreground notification indicates the capture session
- Wi-Fi/Bluetooth settings, Android Settings, and battery status from Phase 4

## Privacy and platform behavior
- No screenshot is taken unless the user taps the button and approves Android's prompt.
- Android may display protected content as blank, and some apps prevent capture.
- This is a manual button flow; voice command / wake-word integration is not included yet.
- This starter does not silently control device settings or bypass Android permissions.
- The original NOVA Normal/SHADOW dashboard image assets were not available in the source project, so this project does not invent a replacement design.

## Build
Open the folder in Android Studio, sync Gradle, then use:
Build → Build Bundle(s) / APK(s) → Build APK(s)

Package: `com.nova.assistant`
Version: `5.0`
Minimum Android: 8.0 (API 26)
Target SDK: 35
