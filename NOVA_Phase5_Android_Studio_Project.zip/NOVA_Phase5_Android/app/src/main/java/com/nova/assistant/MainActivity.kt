package com.nova.assistant

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val captureRequestCode = 5051

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 44, 32, 32)
        }
        layout.addView(TextView(this).apply {
            text = "NOVA — Phase 5"
            textSize = 26f
        })
        layout.addView(TextView(this).apply {
            text = "Capture one screenshot only after you approve Android's screen-sharing prompt."
            textSize = 15f
            setPadding(0, 12, 0, 18)
        })
        layout.addView(actionButton("Take screen screenshot") { requestCapture() })
        layout.addView(actionButton("Open Wi-Fi settings") { safeStart(Intent(Settings.Panel.ACTION_WIFI)) })
        layout.addView(actionButton("Open Bluetooth settings") { safeStart(Intent(Settings.Panel.ACTION_BLUETOOTH)) })
        layout.addView(actionButton("Open device settings") { safeStart(Intent(Settings.ACTION_SETTINGS)) })
        layout.addView(actionButton("Show battery status") { showBatteryStatus() })
        setContentView(layout)
    }

    private fun actionButton(label: String, action: () -> Unit) =
        Button(this).apply {
            text = label
            setOnClickListener { action() }
        }

    private fun requestCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequestCode)
    }

    @Deprecated("Android activity result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequestCode) {
            if (resultCode == RESULT_OK && data != null) {
                val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                }
                try {
                    startForegroundService(serviceIntent)
                } catch (e: Exception) {
                    Toast.makeText(this, "Could not start capture: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this, "Screen capture permission was not granted.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun safeStart(intent: Intent) {
        try {
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "This screen is not available on this device.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showBatteryStatus() {
        val manager = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        Toast.makeText(this, if (level in 0..100) "Battery: $level%" else "Battery unavailable", Toast.LENGTH_LONG).show()
    }
}
