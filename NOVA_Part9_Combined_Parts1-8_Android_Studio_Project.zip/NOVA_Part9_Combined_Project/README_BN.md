# NOVA — Combined Android Project (Part 9)

এই ZIP-টি Part 4–8-এর পাওয়া Android source থেকে একটি একক Android Studio project হিসেবে সাজানো হয়েছে। Part 1–3-এর আলাদা Android source ZIP Library-তে পাওয়া যায়নি; তাই আগের কথোপকথনে নিশ্চিত হওয়া বেসিক NOVA launcher/dashboard, voice interaction ও phone-action ধারণা ধরে সেগুলোর প্রয়োজনীয় ভিত্তি পুনর্গঠন করা হয়েছে।

## এখন যা যুক্ত আছে
- Android app launcher: NOVA
- বাংলা (bn-IN) tap-to-talk speech recognition
- Text-to-Speech উত্তর (ফোনে বাংলা TTS voice থাকলে)
- কথোপকথন চালু/বন্ধ করার স্পষ্ট বোতাম
- Wi-Fi ও Bluetooth-এর Android system panel খোলা
- Android Settings খোলা
- Battery percentage বলা
- Screenshot command/button; প্রতিবার Android-এর screen-capture consent prompt
- একবারের screenshot `Pictures/NOVA`-তে PNG হিসেবে সেভ করার চেষ্টা
- Help, greeting, name, time ও সাধারণ কথার জন্য local response

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি এখনো পূর্ণ AI assistant নয়। সাধারণ কথার উত্তর সীমিত local rules দিয়ে হয়; কোনো AI API/server যুক্ত নেই।
- সবসময় background-এ wake-word শোনা হয় না। ব্যবহারকারী Listen চাপলে তবেই মাইক্রোফোন চালু হয়।
- Screenshot কখনো গোপনে নেওয়া হয় না; Android-এর অনুমতি দিতে হবে। কিছু protected app/screen কালো বা ফাঁকা আসতে পারে।
- Part 1–3-এর আসল source ZIP পাওয়া যায়নি, তাই সেগুলোর অজানা feature হুবহু পুনরুদ্ধার করা হয়েছে বলে দাবি করা হচ্ছে না।
- আগের নির্বাচিত split-screen Normal/SHADOW dashboard-এর আসল image asset এই পাওয়া ফাইলগুলোর মধ্যে ছিল না। তাই এই build-এ সেটি হুবহু বসানো হয়নি; ভুল ছবি দিয়ে বদলানো হয়নি।

## Android Studio-তে খোলা
1. ZIP extract করো।
2. Android Studio → Open → extract করা `NOVA_Part9_Combined_Project` folder নির্বাচন করো।
3. Gradle sync শেষ হতে দাও (প্রথমবার internet লাগতে পারে)।
4. Android ফোনে USB debugging চালু করে Run করো, অথবা APK build করো।
5. প্রথমবার Listen চাপলে Microphone permission দাও।

## যাচাইয়ের অবস্থা
এই পরিবেশে Android SDK/Gradle build tool পাওয়া যায়নি। তাই ZIP integrity, project structure, manifest XML ও source consistency পরীক্ষা করা হয়েছে; APK compile, emulator run বা বাস্তব ফোনে microphone/screenshot পরীক্ষা করা হয়নি। Android Studio-তে প্রথম Gradle sync/build-ই পরের বাস্তব build verification।
