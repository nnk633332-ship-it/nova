package com.nova.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private val captureRequestCode = 6051
    private val audioPermissionRequest = 6052
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var statusText: TextView
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 44, 32, 32)
        }
        layout.addView(TextView(this).apply {
            text = "NOVA — Phase 6"
            textSize = 26f
        })
        statusText = TextView(this).apply {
            text = "Voice command ready. Tap the microphone button to speak."
            textSize = 15f
            setPadding(0, 12, 0, 18)
        }
        layout.addView(statusText)
        layout.addView(actionButton("🎙 Speak to NOVA") { startVoiceCommand() })
        layout.addView(actionButton("Take screen screenshot") { requestCapture() })
        layout.addView(actionButton("Open Wi-Fi settings") { safeStart(Intent(Settings.Panel.ACTION_WIFI)) })
        layout.addView(actionButton("Open Bluetooth settings") { safeStart(Intent(Settings.Panel.ACTION_BLUETOOTH)) })
        layout.addView(actionButton("Open device settings") { safeStart(Intent(Settings.ACTION_SETTINGS)) })
        layout.addView(actionButton("Show battery status") { showBatteryStatus() })
        setContentView(layout)
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale.getDefault()
    }

    private fun say(message: String) {
        statusText.text = message
        if (ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "nova_reply")
    }

    private fun actionButton(label: String, action: () -> Unit) =
        Button(this).apply {
            text = label
            setOnClickListener { action() }
        }

    private fun startVoiceCommand() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Voice recognition is not available on this phone.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
            return
        }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { say("I'm listening.") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { statusText.text = "Understanding..." }
                override fun onError(error: Int) { say("I couldn't understand. Please try again.") }
                override fun onResults(results: Bundle?) {
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val command = words?.firstOrNull().orEmpty()
                    if (command.isBlank()) say("I didn't hear a command.") else handleCommand(command)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val request = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
            speechRecognizer?.startListening(request)
        } catch (e: Exception) {
            say("Voice recognition could not start.")
        }
    }

    private fun handleCommand(raw: String) {
        val command = raw.lowercase(Locale.getDefault())
        when {
            command.contains("screenshot") || command.contains("screen shot") -> {
                say("I'll ask permission to capture the screen.")
                requestCapture()
            }
            command.contains("wi-fi") || command.contains("wifi") -> {
                say("Opening Wi-Fi settings.")
                safeStart(Intent(Settings.Panel.ACTION_WIFI))
            }
            command.contains("bluetooth") -> {
                say("Opening Bluetooth settings.")
                safeStart(Intent(Settings.Panel.ACTION_BLUETOOTH))
            }
            command.contains("battery") || command.contains("charge") -> showBatteryStatus()
            command.contains("settings") -> {
                say("Opening device settings.")
                safeStart(Intent(Settings.ACTION_SETTINGS))
            }
            else -> say("I heard: $raw. That command isn't supported yet.")
        }
    }

    private fun requestCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequestCode)
    }

    @Deprecated("Android activity result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequestCode) {
            if (resultCode == RESULT_OK && data != null) {
                val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                }
                try {
                    startForegroundService(serviceIntent)
                    say("Screen capture approved. Taking one screenshot.")
                } catch (e: Exception) {
                    say("I couldn't start the screenshot service.")
                }
            } else {
                say("Screen capture permission was not granted.")
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequest) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startVoiceCommand()
            } else {
                say("Microphone permission is needed for voice commands.")
            }
        }
    }

    private fun safeStart(intent: Intent) {
        try {
            startActivity(intent)
        } catch (_: Exception) {
            say("That settings screen is not available on this device.")
        }
    }

    private fun showBatteryStatus() {
        val manager = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        say(if (level in 0..100) "Your battery is at $level percent." else "Battery level is unavailable.")
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
