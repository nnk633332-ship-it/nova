# NOVA — Phase 6 Android Studio project

Phase 6 adds tap-to-talk voice commands and spoken replies to the Phase 5 native Android project.

## Voice commands currently recognized
- "Take screenshot" / "screenshot" — asks Android for screen-capture permission, then captures one frame if approved
- "Open Wi-Fi" — opens Android's Wi-Fi panel
- "Open Bluetooth" — opens Android's Bluetooth panel
- "Battery" / "charge" — speaks the battery percentage
- "Open settings" — opens Android Settings

## Notes
- Tap **Speak to NOVA** before speaking. This is not an always-listening wake-word service.
- Android asks for microphone permission before the first voice use.
- Speech recognition language and availability depend on the device's recognition service. Some services require internet; offline recognition is not guaranteed.
- Text-to-speech uses the language/voice installed on the phone.
- Screen capture requires the user's explicit Android consent dialog each session.
- Wi-Fi and Bluetooth controls open Android system panels; NOVA does not silently toggle them.
- The original NOVA Normal/SHADOW split-screen art assets were not available in the project files, so no substitute dashboard design is included.

## Build
Open this folder in Android Studio, sync Gradle, then choose:
Build → Build Bundle(s) / APK(s) → Build APK(s)

Package: `com.nova.assistant`
Version: `6.0`
Minimum Android: 8.0 (API 26)
Target SDK: 35
