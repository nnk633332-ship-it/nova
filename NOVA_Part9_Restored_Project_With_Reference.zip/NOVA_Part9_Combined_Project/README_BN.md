# NOVA Android Project

এই Project-এ Part 4–8-এর মূল ZIP reference হিসেবে রাখা হয়েছে এবং একটি reconstructed Android app shell আছে।

## Build configuration
- Android application ID: `com.nova.assistant`
- Compile SDK: 35
- Minimum Android: 8.0 (API 26)
- Target SDK: 35
- Kotlin plugin: 2.0.21
- Android Gradle Plugin: 8.7.3

## Build status
এই পরিবেশে Android SDK ও Gradle executable পাওয়া যায়নি; তাই APK তৈরি বা compile verification করা হয়নি। ফোনে Android build IDE/SDK-সহ উপযুক্ত পরিবেশে Project খুলে sync/build করতে হবে।

## Features currently in source
- Bengali speech input via Android SpeechRecognizer (`bn-IN`)
- Bengali text-to-speech via Android TTS
- Basic local command handling
- Wi-Fi, Bluetooth, Settings shortcuts
- Battery level
- One-shot screenshot flow requiring Android's explicit screen-capture consent

## Important limitations
- No online AI backend/API is connected.
- No always-on wake-word service is implemented.
- The complete Normal/SHADOW split dashboard artwork is not present. The available reference image is stored at `app/src/main/res/drawable-nodpi/nova_normal_reference.png`.
- Original Parts 1–3 source files were not available; the current base is a reconstruction, not a verbatim recovery.
- See `docs/MISSING_ITEMS_BN.md` for details.
