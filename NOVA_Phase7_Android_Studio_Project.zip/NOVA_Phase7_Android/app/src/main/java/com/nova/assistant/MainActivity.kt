package com.nova.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private val captureRequestCode = 7051
    private val audioPermissionRequest = 7052
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private lateinit var statusText: TextView
    private lateinit var heardText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 42, 30, 30)
        }
        layout.addView(TextView(this).apply {
            text = "NOVA — Phase 7"
            textSize = 26f
        })
        statusText = TextView(this).apply {
            text = "NOVA is ready. Tap Listen and speak a command."
            textSize = 16f
            setPadding(0, 14, 0, 10)
        }
        heardText = TextView(this).apply {
            text = "Heard: —"
            textSize = 14f
            setPadding(0, 0, 0, 18)
        }
        layout.addView(statusText)
        layout.addView(heardText)
        layout.addView(actionButton("🎙 Listen to command") { startVoiceCommand() })
        layout.addView(actionButton("Stop listening") { stopListening() })
        layout.addView(actionButton("Take screenshot") { requestCapture() })
        layout.addView(actionButton("Open Wi-Fi settings") { safeStart(Intent(Settings.Panel.ACTION_WIFI)) })
        layout.addView(actionButton("Open Bluetooth settings") { safeStart(Intent(Settings.Panel.ACTION_BLUETOOTH)) })
        layout.addView(actionButton("Open device settings") { safeStart(Intent(Settings.ACTION_SETTINGS)) })
        layout.addView(actionButton("Show battery") { showBatteryStatus() })
        layout.addView(actionButton("Open NOVA help") { speak("Say screenshot, open Wi-Fi, open Bluetooth, battery, or open settings.") })
        setContentView(layout)
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale.getDefault()
    }

    private fun speak(message: String) {
        statusText.text = message
        if (ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "nova_voice_reply")
    }

    private fun actionButton(label: String, action: () -> Unit) =
        Button(this).apply { text = label; setOnClickListener { action() } }

    private fun startVoiceCommand() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Speech recognition is unavailable on this phone.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
            return
        }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { speak("I'm listening. Please speak.") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { statusText.text = "Processing your command..." }
                override fun onError(error: Int) { speak("I couldn't hear that clearly. Tap Listen and try again.") }
                override fun onResults(results: Bundle?) {
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val command = words?.firstOrNull().orEmpty()
                    heardText.text = "Heard: $command"
                    if (command.isBlank()) speak("I didn't hear a command.") else handleCommand(command)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val request = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
            speechRecognizer?.startListening(request)
        } catch (_: Exception) {
            speak("Voice command could not start.")
        }
    }

    private fun stopListening() {
        speechRecognizer?.stopListening()
        speechRecognizer?.cancel()
        speak("Voice listening stopped.")
    }

    private fun handleCommand(raw: String) {
        val c = raw.lowercase(Locale.ROOT)
        when {
            c.contains("screenshot") || c.contains("screen shot") -> {
                speak("I'll request Android's permission to capture one screenshot.")
                requestCapture()
            }
            c.contains("wifi") || c.contains("wi-fi") -> {
                speak("Opening Wi-Fi settings.")
                safeStart(Intent(Settings.Panel.ACTION_WIFI))
            }
            c.contains("bluetooth") -> {
                speak("Opening Bluetooth settings.")
                safeStart(Intent(Settings.Panel.ACTION_BLUETOOTH))
            }
            c.contains("battery") || c.contains("charge") -> showBatteryStatus()
            c.contains("settings") -> {
                speak("Opening device settings.")
                safeStart(Intent(Settings.ACTION_SETTINGS))
            }
            c.contains("help") || c.contains("what can you do") -> speak("I can help with screenshots, Wi-Fi, Bluetooth, battery status and device settings.")
            else -> speak("I heard: $raw. I don't have an action for that command yet.")
        }
    }

    private fun requestCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequestCode)
    }

    @Deprecated("Android activity result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequestCode) {
            if (resultCode == RESULT_OK && data != null) {
                val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                }
                try {
                    startForegroundService(serviceIntent)
                    speak("Permission approved. Capturing one screenshot.")
                } catch (_: Exception) {
                    speak("I couldn't start the screenshot service.")
                }
            } else {
                speak("Screenshot permission was not approved.")
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequest) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startVoiceCommand()
            else speak("Microphone permission is required for voice commands.")
        }
    }

    private fun safeStart(intent: Intent) {
        try { startActivity(intent) } catch (_: Exception) { speak("That settings screen is unavailable.") }
    }

    private fun showBatteryStatus() {
        val manager = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        speak(if (level in 0..100) "Your battery is at $level percent." else "Battery level is unavailable.")
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
