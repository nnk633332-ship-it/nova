# NOVA — Phase 7 Android Studio project

Phase 7 improves the manual voice-command interface.

## Added
- Clear "Listen to command" and "Stop listening" controls
- Shows the recognized phrase on screen
- Spoken confirmation and help command
- Handles the supported commands: screenshot, Wi-Fi, Bluetooth, battery, settings, help
- Retains the Phase 5 one-shot screenshot capture and Phase 6 speech/TTS integration

## Important limits
- This is tap-to-talk, not always-on wake-word listening.
- Microphone use requires Android runtime permission.
- Recognition language/offline capability depends on the phone's speech service.
- Screenshot capture requires Android's own consent prompt each time.
- Protected screens may appear blank.
- Original NOVA Normal/SHADOW dashboard assets are not present in the available project files, so this project does not replace them.

## Build
Open this folder in Android Studio, sync Gradle, then select:
Build → Build Bundle(s) / APK(s) → Build APK(s)

Package: `com.nova.assistant`
Version: `7.0`
Minimum Android: 8.0 (API 26)
Target SDK: 35
